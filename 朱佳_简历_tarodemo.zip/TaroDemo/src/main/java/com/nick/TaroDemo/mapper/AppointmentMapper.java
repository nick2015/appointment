package com.nick.TaroDemo.mapper;

import com.mybatisflex.core.BaseMapper;
import com.nick.TaroDemo.entity.Appointment;

public interface AppointmentMapper extends BaseMapper<Appointment>{
}
