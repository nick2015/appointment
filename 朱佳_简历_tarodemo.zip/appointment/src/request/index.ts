import HttpClient  from './httpClient';

const httpClient = new HttpClient();

export default httpClient;
