export interface AppointmentDto {
  id?: string;
  userId?: string;
  subject: string;
  startTime: string; 
  endTime: string;
}