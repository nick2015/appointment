export const HTTP_RESPONSE_STATE = {
  success: '0000',
  needAuth: '0001', // 未登录或登录失效
}

export const APP_SERVER_URL = "http://localhost:8888";

export const TOKEN = "X-Auth-Token";